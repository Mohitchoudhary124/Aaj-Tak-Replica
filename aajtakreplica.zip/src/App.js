import './App.css';
import Homepage from './assets/pages/Homepage';
import { register } from 'swiper/element/bundle';


function App() {
  return (
    <div>
     <Homepage/>
    </div>
  );
}
register();

export default App;
